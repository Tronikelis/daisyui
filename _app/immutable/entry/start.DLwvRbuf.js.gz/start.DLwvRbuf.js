import{a as t}from"../chunks/entry.DRi5SUsh.js";export{t as start};

import{a as t}from"../chunks/entry.CNQT6NV0.js";export{t as start};
